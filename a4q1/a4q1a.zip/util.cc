#include "util.h"

void getString( std::istream & in, std::string & s, const char * fieldType ) {
    getline( in, s );

    // *** If getline fails to obtain the necessary argument, raise
    // *** std::runtime_error initialized with the fiedlType parameter passed in.

} // getString

void getInteger( std::istream & in, int & i, const char * fieldType ) {
    std::string s;
    getline( in, s );

    // *** If std::stoi fails, or getline fails to obtain the necessary argument, raise
    // *** std::runtime_error initialized with the fiedlType parameter passed in.

    i = std::stoi(s);
} // getInteger
