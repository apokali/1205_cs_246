#ifndef _LIBRARY_ITERATOR
#define _LIBRARY_ITERATOR

#include <string>
class Library; // forward declarations
class DigitalMedia;

class LibraryIterator {
    friend class Library;

    // *** fill in

    explicit LibraryIterator( /*** fill in ***/ );  // Private constructor

public:
    DigitalMedia * operator*();
    LibraryIterator operator++();
    bool operator==(const LibraryIterator &other) const;
    bool operator!=(const LibraryIterator &other) const;    
};

#endif
